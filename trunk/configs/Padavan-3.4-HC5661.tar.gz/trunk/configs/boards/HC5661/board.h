/* HiWiFi HC5661 (极路由 1S) */

#define BOARD_PID		"HC5661"
#define BOARD_NAME		"HC5661"
#define BOARD_DESC		"HiWiFi HC5661 Wireless Router"
#define BOARD_VENDOR_NAME	"HiWiFi"
#define BOARD_VENDOR_URL	"http://www.hiwifi.com/"
#define BOARD_MODEL_URL		"http://www.hiwifi.com/"
#define BOARD_BOOT_TIME		25
#define BOARD_FLASH_TIME	120
#define BOARD_GPIO_BTN_RESET	12	/* DTS: gpio0 12, 低电平有效 */
#define BOARD_GPIO_LED_INVERTED
#undef  BOARD_GPIO_BTN_WPS
#undef  BOARD_GPIO_LED_ALL
#undef  BOARD_GPIO_LED_WIFI
#undef  BOARD_GPIO_LED_SW2G
#define BOARD_GPIO_LED_POWER	9	/* DTS: 蓝色状态灯 gpio0 9 */
#undef  BOARD_GPIO_LED_LAN
#define BOARD_GPIO_LED_WAN	11	/* DTS: WAN 灯 gpio0 11 */
#undef  BOARD_GPIO_LED_USB
#undef  BOARD_GPIO_LED_ROUTER
#undef  BOARD_GPIO_PWR_USB
#define BOARD_HAS_5G_11AC	0
#define BOARD_NUM_ANT_5G_TX	0
#define BOARD_NUM_ANT_5G_RX	0
#define BOARD_NUM_ANT_2G_TX	2
#define BOARD_NUM_ANT_2G_RX	2
#define BOARD_NUM_ETH_LEDS	0
#define BOARD_NUM_ETH_EPHY	3
#define BOARD_HAS_EPHY_L1000	0
#define BOARD_HAS_EPHY_W1000	0
